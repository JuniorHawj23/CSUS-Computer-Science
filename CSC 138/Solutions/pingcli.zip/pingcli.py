import socket
import sys
import time

def create_client(server_hostname, server_port):
    #Create a UDP socket
    cli_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_address = (server_hostname, server_port)

    sent_count = 0
    received_count = 0
    min_rtt = float('inf')
    max_rtt = 0
    total_rtt = 0

    for sequence_number in range(1, 11):
        message = f"PING {sequence_number} {int(time.time())}"
        sent_time = time.time()
        #Send a Ping message to the server
        cli_socket.sendto(message.encode(), server_address)

        try:
            cli_socket.settimeout(1)  # Wait up to 1 second for a response
            data, server_address = cli_socket.recvfrom(1024)
            received_time = time.time()
            rtt = (received_time - sent_time) * 1000
            print(f"Received PONG from {server_address} (RTT: {rtt:.2f} ms)")
            received_count += 1
            min_rtt = min(min_rtt, rtt)
            max_rtt = max(max_rtt, rtt)
            total_rtt += rtt
        except socket.timeout:
            print(f"Request timed out for sequence {sequence_number}")

        sent_count += 1

    cli_socket.close()

    loss_rate = (sent_count - received_count) / sent_count * 100 if sent_count > 0 else 0
    avg_rtt = total_rtt / received_count if received_count > 0 else 0

    print("\nPing statistics:")
    print(f"Sent = {sent_count}, Received = {received_count}, Loss rate = {loss_rate:.2f}%")
    print(f"Minimum RTT = {min_rtt:.2f} ms, Maximum RTT = {max_rtt:.2f} ms, Average RTT = {avg_rtt:.2f} ms")

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 pingcli.py <hostname> <port>")
        sys.exit(1)

    server_hostname = sys.argv[1]
    server_port = int(sys.argv[2])
    create_client(server_hostname, server_port)

if __name__ == "__main__":
    main()   
