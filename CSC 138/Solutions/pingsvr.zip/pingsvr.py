import socket
import sys
import time

def create_server(port):
    # Create a UDP socket
    svr_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # Bind the socket to the specified port
    svr_socket.bind(("0.0.0.0", port))

    print("UDP Ping Server is listening on port", port)

    while True:
        try:
            # Receive data and client address
            data, client_address = svr_socket.recvfrom(1024)
            message = data.decode()
            print(f"Received PING from {client_address}")
            # Simulate packet loss (30% chance of not responding)
            if time.time() % 10 < 3:
                response = "PONG"
                svr_socket.sendto(response.encode(), client_address)
                print(f"Sent PONG to {client_address}")
            else:
                print("Packet was lost.")
        except KeyboardInterrupt:
            print("Server terminated.")
            break

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 pingsvr.py <port>")
        sys.exit(1)

    port = int(sys.argv[1])
    create_server(port)

if __name__ == "__main__":
    main()
